import React from 'react';

export default function ErrorPage() {
  return <div>ErrorPage</div>;
}
