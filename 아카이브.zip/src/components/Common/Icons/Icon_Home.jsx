import React from 'react';

export default function Icon_Home() {
  return <div>Icon_Home</div>;
}
